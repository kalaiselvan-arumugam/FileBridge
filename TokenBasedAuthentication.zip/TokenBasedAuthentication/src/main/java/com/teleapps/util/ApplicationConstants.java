package com.teleapps.util;

public class ApplicationConstants {

	public static final String AuthenticateController = "/authenticate";
	public static final String WelcomeController = "/welcome";

}
