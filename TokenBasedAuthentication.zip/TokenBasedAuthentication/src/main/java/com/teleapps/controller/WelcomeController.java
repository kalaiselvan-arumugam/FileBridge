package com.teleapps.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.teleapps.util.ApplicationConstants;

@RestController
@CrossOrigin()
public class WelcomeController {


	@RequestMapping({ ApplicationConstants.WelcomeController })
	public String welcome() {

		return "Welcome to TeleApps";
	}

}
